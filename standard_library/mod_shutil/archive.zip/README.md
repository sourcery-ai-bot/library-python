# Shutil Standard Module

This directory contains code samples using the shutil module from the standard Python library.

It can be used to create archives in various formats.
